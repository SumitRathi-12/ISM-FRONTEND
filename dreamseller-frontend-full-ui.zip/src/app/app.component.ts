
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <nav>
      <a routerLink="/orders">Orders</a> |
      <a routerLink="/add">Add Product</a> |
      <a routerLink="/stats">Statistics</a>
    </nav>
    <router-outlet></router-outlet>
  `
})
export class AppComponent {}
