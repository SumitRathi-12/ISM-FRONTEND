
import { Component } from '@angular/core';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html'
})
export class AddProductComponent {
  product = { name: '', price: 0 };

  constructor(private apiService: ApiService) {}

  addProduct(): void {
    this.apiService.addProduct(this.product).subscribe(() => {
      alert('Product added!');
    });
  }
}
