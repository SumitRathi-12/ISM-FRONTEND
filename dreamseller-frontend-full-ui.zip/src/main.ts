import 'zone.js';
console.log('App bootstrapped');